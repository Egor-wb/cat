"use strict"

//Модально окно
function modal() {
    const modal = document.createElement('div');
    modal.classList.add('modal');
    modal.insertAdjacentHTML('afterbegin',
        `
        <div class="modal">
            <div class="shadow_modal" data-close="true">
                <div class="modal_body">
                    <div class="modal_block">
                        <div class="modal_title">
                            <h2 class="title_text">Подписаться на акции и <br> специальные предложения</h2>
                        </div>
                        <div class="modal_input">
                            <form>
                                <input type="email" name="email" class="inputModal" placeholder="Почта" required>
                                <button type="submit" class="btnInputModal">Подписаться</button>
                            </form>
                        </div>
                        
                    </div>
                    <div class = "modal-checkwrap">
                        <div class="modal_checkbox">
                            <div class="modal_item">
                                <input class="inputCheckbox" type="checkbox">
                            </div>
                            <div class="modal_item">
                                <p class="textCheckbox">Я согласен на обработку персональных данных,<br> также с условиями подписки</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>    
        `
    );
    document.body.appendChild(modal);

    let shadowModal = document.querySelector('.shadow_modal');
    let modalWindow = document.querySelector('.modal');

    function closeModal() {
        if (event.target.dataset.close) {
            shadowModal.classList.add('close');
        }
    };

    shadowModal.addEventListener('click', closeModal)
    return modal;
};


setTimeout(() => {
    modal();
}, 5000);


// const filter = document.querySelector('.catalog-container__link');
// const filter_menu = document.querySelector('.catalog-container__menu');
// const body = document.querySelector('body');
// const closes = document.querySelector('.closes');

// const catalogWrap = document.querySelector('.catalog-container__wrap');
// filter.addEventListener('click', () => {
//     filter_menu.classList.toggle('shows');
//     body.classList.add('hidden');
//     catalogWrap.classList.add('position');

//     catalogWrap.addEventListener('click', () => {

//         closes.classList.remove('closes');
//         filter_menu.classList.remove('shows');
//         body.classList.remove('hidden');
//         catalogWrap.classList.remove('position');
//     });
// });



//Прогресс бар 
// function progress() {
//     const elementProgress = document.querySelector('.title-line-progress__item');
//     let second = 1000/60;
//     let timer = second * 10;
//     let width = 1;
//     let id = setInterval(progressStatus, 10);
//     function progressStatus() {
//         if(width >= 100) {
//             clearInterval(id);
//         } else {
//             width++;
//             elementProgress.style.width = width + '%'
//         }
//     };
// };

// progress();



//Кнопка скролл вверх
const offset = 300;
const scrollUp = document.querySelector('.arrowApp');
const scrollHeader = document.querySelector('.hedaer-scroll')

const getTop = () => window.pageYOffset || document.documentElement.scrollTop;

window.addEventListener('scroll', () => {
    if (getTop() > offset) {
        scrollUp.classList.add('arrowApp-active');
        scrollHeader.classList.add('hedaer-scroll-active');
    } else {
        scrollUp.classList.remove('arrowApp-active');
        scrollHeader.classList.remove('hedaer-scroll-active');
    }
});


scrollUp.addEventListener('click', () => {
    window.scrollTo({
        top: 0,
        behavior: "smooth"
    });
});



// Кнопка для активации меню 

const btnMenu = document.querySelector('.header-btn');
const btn_menu = document.querySelector('.btn_menu');
const btnMenuMobal = document.querySelector('.header-btn__mobail');
const closeMenuBody = document.querySelector('.menu__body__close');
const closeMenuBodyDecstop = document.querySelector('.decstop');
const menuBody = document.querySelector('.menu__body');
const ipad = document.querySelector('.ipad');


if (btnMenu) {
    btnMenu.addEventListener('click', e => {
        document.body.classList.toggle('_lock');
        btnMenu.classList.toggle('menu__body__active');
        menuBody.classList.toggle('menu__body__active');
    });
};

if (btn_menu) {
    btn_menu.addEventListener('click', e => {
        document.body.classList.toggle('_lock');
        btn_menu.classList.toggle('menu__body__active');
        menuBody.classList.toggle('menu__body__active');
        scrollHeader.classList.remove('hedaer-scroll-active');

    });
};

if (btnMenuMobal) {
    btnMenuMobal.addEventListener('click', e => {
        document.body.classList.toggle('_lock');
        btnMenuMobal.classList.toggle('menu__body__active');
        menuBody.classList.toggle('menu__body__active');
    });
};

if (closeMenuBody) {
    closeMenuBody.addEventListener('click', e => {
        document.body.classList.remove('_lock');
        btnMenu.classList.remove('menu__body__active');
        menuBody.classList.remove('menu__body__active')
    });
};

if (closeMenuBodyDecstop) {
    closeMenuBodyDecstop.addEventListener('click', e => {
        document.body.classList.remove('_lock');
        btnMenu.classList.remove('menu__body__active');
        menuBody.classList.remove('menu__body__active')
    });
};

if (ipad) {
    ipad.addEventListener('click', e => {
        document.body.classList.remove('_lock');
        btnMenu.classList.remove('menu__body__active');
        menuBody.classList.remove('menu__body__active')
    });
};



//Слайдер jQuery + slick



$(function() {
    $('.popularCategories-block').slick({
      infinite: true,
      slidesToShow: 5,
      slidesToScroll: 1,
      responsive: [
      {
                breakpoint: 980,
                settings: {
                    slidesToShow: 3,
                    slidesToScroll: 1,
                    arrows: false,
                    infinite: true,
                }
            },
            {
                breakpoint: 480,
                settings: {
                    slidesToShow: 3,
                    slidesToScroll: 1,
                    arrows: false,
                    infinite: true,
                }
            }
        ]
    });
});


$(function() {
    $('.besteller-block').slick({
        infinite: true,
        slidesToShow: 4,
        slidesToScroll: 1,
        arrows: true,
        autoplay: true,
        autoplaySpeed: 2000,
        speed: 1500,
        responsive: [
        {
                breakpoint: 980,
                settings: {
                    slidesToShow: 3,
                    slidesToScroll: 1,
                    arrows: false,
                    infinite: true,
                }
            },
            {
                breakpoint: 480,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 1,
                    arrows: false,
                    infinite: true,
                }
            }
        ]
    });
});


$(function() {
    $('.news_block_item_slider').slick({
        infinite: true,
        slidesToShow: 2,
        slidesToScroll: 1,
        arrows: true,
        autoplay: true,
        autoplaySpeed: 2000,
        speed: 1500,
       
    });
});



// $(function() {
//     $('.besteller-block-mob').slick({
//         infinite: true,
//         slidesToShow: 3,
//         slidesToScroll: 1,
//         arrows: true,
//         autoplay: true,
//         autoplaySpeed: 2000,
//         speed: 1500,
//         responsive: [{
//                 breakpoint: 768,
//                 settings: {
//                     slidesToShow: 3,
//                     slidesToScroll: 1,
//                     arrows: false,
//                     infinite: true,
//                 }
//             },
//             {
//                 breakpoint: 480,
//                 settings: {
//                     slidesToShow: 1,
//                     slidesToScroll: 1,
//                     arrows: false,
//                     infinite: true,
//                 }
//             }
//         ]
//     });
// });

$(function() {
$('.slider-for').slick({
                      slidesToShow: 1,
                      slidesToScroll: 1,
                      arrows: false,
                      fade: true,
                      asNavFor: '.slider-nav'
                    });
                    $('.slider-nav').slick({
                      slidesToShow: 6,
                      slidesToScroll: 1,
                      asNavFor: '.slider-for',
                      dots: true,
                      vertical: true,
                      verticalSwiping: true,
                      centerMode: true,
                      focusOnSelect: true,

                        responsive: [
                                {
                                    breakpoint: 767,
                                    settings: "unslick"
                                } 
                        ]
    });
});

// $(function() {
//     $('.slider-for').slick({
//       slidesToShow: 1,
//       slidesToScroll: 1,
//       arrows: false,
//       fade: true,
//       vertical: true,
//         verticalSwiping: true,
//       asNavFor: '.slider-nav'
//     });
//     $('.slider-nav').slick({
//       slidesToShow: 3,
//       slidesToScroll: 1,
//       asNavFor: '.slider-for',
//       dots: true,
//       centerMode: true,
//       focusOnSelect: true
//     });
// });






// Переключатель в catalog Filter

const btnFilterLeft = document.querySelector('.catalog-filter__left');
const btnFilterRight = document.querySelector('.catalog-filter__right');


btnFilterRight.addEventListener('click', () => {
    btnFilterRight.classList.add('catalog-toggle_colorGray');
    btnFilterLeft.classList.remove('catalog-toggle_colorGray');
});

//скролинг хедера
jQuery("document").ready(function($){
 
    var nav = $('.main-menu');
     var log = $('.logo');
    
    $(window).scroll(function () {
        if ($(this).scrollTop() > 236) {
            nav.addClass("f-nav");
            nav.addClass("bg-menu");
            log.addClass("logo-bg");
            $(".btn-none").css("display", "block");
            $(".nav-link").css("color", "#00022A");
        } else {
            nav.removeClass("f-nav");
            nav.removeClass("bg-menu");
            log.removeClass("logo-bg"); 
            $(".btn-none").css("display", "none");
            $(".nav-link").css("color", "#fff");
        }
    });
 
});



// Select in catalog Filter
function select() {
    let selectHeaddr = document.querySelectorAll('.catalog-select__header');
    let selectItem = document.querySelectorAll('.catalog-select__item');
    let selectArrow = document.querySelector('.fa-chevron-down');


    selectHeaddr.forEach(item => {
        item.addEventListener('click', selectToggle);
    });

    selectItem.forEach(item => {
        item.addEventListener('click', selectChoose);
    });

    // selectArrow.addEventListener('click', () => {
    //     selectArrow.classList.add('select-arrow__deg');
    // })

    function selectToggle() {
        this.parentElement.classList.toggle('is-active');
        selectArrow.classList.toggle('select-arrow__deg');
    };

    function selectChoose() {
        let text = this.innerText,
            select = this.closest('.catalog-select'),
            currentText = this.closest('.catalog-select').querySelector('.catalog-select__current');
        currentText.innerText = text;
        select.classList.remove('is-active');
        selectArrow.classList.toggle('select-arrow__deg');
    }
};
select();