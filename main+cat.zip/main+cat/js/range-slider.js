const rangeSlider = document.querySelector('#range-slider');

if(rangeSlider) {
    noUiSlider.create(rangeSlider, {
        start: [2100, 24550],
        connect: true,
        step:1,
        range: {
            'min': [0],
            'max': [99000]
        }
    });

    const inputLeft = document.querySelector('.inputLeft');
    const inputRight = document.querySelector('.inputRight');
    const inputs = [inputLeft, inputRight];

    rangeSlider.noUiSlider.on('update', (values, handle) => {
        inputs[handle].value = Math.round(values[handle]);
    });

    const setRangeSlider = (i, value) => {
        let arr = [null, null];
        arr[i] = value;

        rangeSlider.noUiSlider.set(arr);
    };

    inputs.forEach((el, index)=> {
        el.addEventListener('change', e => {
            setRangeSlider(index, e.currentTarget.value)
        })
    })
};


